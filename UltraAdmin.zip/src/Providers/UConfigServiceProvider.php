<?php

namespace Fabio\UltraAdmin\Providers;

use Fabio\UltraAdmin\UConfig\UConfig;

class UConfigServiceProvider
{
    /**
     * Metodo per registrare il service provider
     *
     * Qui registriamo `UConfig` come singleton nel container.
     * Questo assicura che `UConfig` sia istanziato una volta sola
     * e che sia disponibile globalmente nell'applicazione.
     */
    public function register(): void
    {
        app()->singleton(UConfig::class, function () {
            // Inizializza e restituisce l'istanza di UConfig
            return new UConfig();
        });
    }

    /**
     * Metodo di avvio per `UConfig`
     *
     * Qui eseguiamo tutte le configurazioni necessarie per `UConfig`
     * e carichiamo le configurazioni base.
     */
    public function boot(): void
    {
        // Carica le configurazioni di base tramite UConfig
        $config = app(UConfig::class);

        // Esempio di caricamento di configurazioni essenziali
        $config::load('logging');
        $config::load('database');
    }
}
