<?php

namespace Fabio\UltraAdmin\Providers;

use Fabio\UltraAdmin\Framework\Router;

class RouteServiceProvider
{
    protected Router $router;

    public function __construct(Router $router)
    {
        $this->router = $router;
    }

    public function boot()
    {
        $config = require __DIR__ . '/../../config/app.php';

        // Includiamo tutte le rotte definite nei file di rotte (web.php, api.php, ecc.)
        foreach ($config['routes'] as $routeFile) {
            if (file_exists($routeFile)) {
                $routeInstance = require $routeFile;
                if ($routeInstance instanceof Router) {
                    foreach ($routeInstance->getRoutes() as $method => $routes) {
                        foreach ($routes as $route => $handler) {
                            $this->router->addRoute($method, $route, $handler);
                        }
                    }
                }
            }
        }
    }
}
