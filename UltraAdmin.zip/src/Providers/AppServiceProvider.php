<?php

namespace Fabio\UltraAdmin\Providers;

use Fabio\UltraAdmin\Framework\Container;

class AppServiceProvider
{
    protected Container $container;

    public function __construct(Container $container)
    {
        $this->container = $container;
    }

    public function boot()
    {
        $config = require __DIR__ . '/../../config/app.php';

        // Registriamo tutti i service provider
        foreach ($config['providers'] as $provider) {
            $providerInstance = new $provider($this->container);
            $providerInstance->register();
            $providerInstance->boot();
        }
    }
}
