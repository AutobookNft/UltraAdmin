<?php

namespace Fabio\UltraAdmin\Core;

use Fabio\UltraAdmin\Framework\Container;

class Kernel
{
    protected array $providers = [];
    protected Container $container;

    public function __construct(Container $container)
    {
        $this->container = $container;
        $this->loadProvidersFromConfig();
    }

    /**
     * Carica i provider definiti nel file di configurazione app.php
     */
    protected function loadProvidersFromConfig(): void
    {
        $config = require __DIR__ . '/../../config/app.php';
        $this->providers = $config['providers'] ?? [];
    }

    /**
     * Avvia tutti i provider registrati
     */
    public function boot(): void
    {
        foreach ($this->providers as $providerClass) {
            $provider = new $providerClass($this->container);
            $provider->register();
            $provider->boot();
        }
    }
}
