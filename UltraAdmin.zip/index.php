<?php

require_once __DIR__ . '/vendor/autoload.php';

use Fabio\UltraAdmin\Controllers\LibraryController;
use Fabio\UltraAdmin\Core\Kernel;
use Fabio\UltraAdmin\Framework\Container;
use Fabio\UltraAdmin\Providers\UltraAdminServiceProvider;
use Fabio\UltraAdmin\Providers\AppServiceProvider;
use Fabio\UltraAdmin\Framework\Router;
use Fabio\UltraAdmin\Helpers\PathHelper;


// Definisce il percorso di base dell'applicazione
PathHelper::setBasePath(__DIR__);

$log = LoggerConfig::getLogger();

$log->info('Applicazione avviata con successo');
$log->error('Errore critico nell\'applicazione');

// Inizializza il container
$container = new Container();

// Registra il provider principale dell'applicazione
$kernel = new Kernel($container);
$kernel->boot();

// Creiamo un'istanza del router
$router = new Router();

// Definiamo la rotta per il percorso radice `/`
$router->addRoute('GET', '/', function () {
    echo "<h1>Benvenuto in UltraAdmin</h1>";
    echo "<p>Questa è la pagina iniziale. Utilizza le seguenti rotte per gestire le librerie:</p>";
    echo "<ul>
            <li><a href='/libraries'>Visualizza tutte le librerie</a></li>
            <li><a href='/libraries/create'>Crea una nuova libreria</a></li>
          </ul>";
});

// Eseguiamo il router per instradare la richiesta
$router->dispatch();

