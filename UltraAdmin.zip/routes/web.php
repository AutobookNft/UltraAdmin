<?php

// routes/web.php

// Definiamo tutte le route qui per tenere il codice organizzato

use Fabio\UltraAdmin\Controllers\LibraryController;
use Fabio\UltraAdmin\Framework\Router;
use Fabio\UltraAdmin\Helpers\PathHelper;

$router = new Router();

$libraryController = new LibraryController();

// Definiamo le route per LibraryController
$router->addRoute('GET', '/libraries', [$libraryController, 'index']);
$router->addRoute('GET', '/libraries/create', [$libraryController, 'create']);
$router->addRoute('POST', '/libraries/store', [$libraryController, 'store']);
$router->addRoute('GET', '/libraries/edit', [$libraryController, 'edit']);
$router->addRoute('POST', '/libraries/update', [$libraryController, 'update']);
$router->addRoute('POST', '/libraries/delete', [$libraryController, 'delete']);

// Definiamo una rotta per una vista HTML statica
$router->addRoute('GET', '/libraries/handle', function () {
    $viewPath = PathHelper::publicPath('handle_library.html');
    $log = LoggerConfig::getLogger();

    $log->info('ViewPath', ['viewPath'=>$viewPath]);

    if (file_exists($viewPath)) {
        echo file_get_contents($viewPath);
    } else {
        http_response_code(404);
        echo "404 - Vista non trovata.";
    }
});

return $router;